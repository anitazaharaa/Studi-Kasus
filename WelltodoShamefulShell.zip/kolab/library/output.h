using namespace std;

class Output {
  public:
    void cetak(){
	cout << "Total belanjaan anda adalah : " << totals<<endl;
	cout << "Masukkan jumlah pembayaran : "; cin >> bayar;
	kembali = bayar - totals;
	cout << "Struk belanja berhasil dicetak"<<endl;
	
	cout<< "===== Struk Belanja ====="<<endl;
 	cout<< "1. Ayam geprek	: " << geprek << " x 21.000 = " << total1<<endl;
  cout<< "2. Ayam goreng	: " << goreng << " x 17.000 = " << total2<<endl;
  cout<< "3. Udang goreng	: " << udang << " x 19.000 = " << total3<<endl;
  cout<< "4. Cumi goreng	: " << cumi << " x 20.000 = " << total4<<endl;
  cout<< "5. Ayam  bakar	: " << bakar << " x 25.000 = " << total5<<endl;
  	
  	cout<< "Diskon	= " << diskon<<endl;
  	cout<< "Ongkir	= " << ongkir2<<endl;
  	cout<< "Bayar 	= " << bayar<<endl;
  	cout<< "Kembali	= " << kembali<<endl; 	
}
  private:
      //ofstream tulis_data;
    	int geprek, goreng, udang, cumi, bakar, total1, total2, total3, total4, total5, total, jarak, ongkir1, ongkir2, diskon, totals, bayar, kembali;
};