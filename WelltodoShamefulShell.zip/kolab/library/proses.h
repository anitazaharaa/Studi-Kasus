using namespace std;

ooclass Proses {
  public :
    void cetak(){
      cout << "Ini Proses \n";
    }

    void getData(){
      ambil_data.open("api.data.txt");
      bool ayam_geprek = true;
      bool ayam_goreng = true;
      bool udang_goreng = true;
      bool cumi_goreng = true;
      bool ayam_bakar = true;
      bool jarak = true;
      while(!ambil_data.eof()){
        if (ayam_geprek){
          ambil_data >> bnyk_geprek;
          ayam_geprek = false;
        }
        if (ayam_goreng){
          ambil_data >> bnyk_aymgoreng;
          ayam_goreng = false;
        }
        if (udang_goreng){
          ambil_data >> bnyk_udanggrng;
          udang_goreng = false;
        }
        if (cumi_goreng){
          ambil_data >> bnyk_cumigrn-7+*+g;
          cumi_goreng = false;
        }
        if (ayam_bakar){
          ambil_data >> bnyk_aymgbakar;
          ayam_bakar = false;
        }
        if (jarak){
          ambil_data >> jrk;
          jarak = false;
        }
        
      }
      ambil_data.close();
    }

    void toFile(){
      int subtotal = (hrg_aymgeprek * bnyk_aymgeprek) + (hrg_aymgoreng * bnyk_aymgoreng) + (hrg_udanggrng * bnyk_udanggrng) + (hrg_cumigrng * bnyk_cumigrng) + (hrg_aymgbakar * bnyk_aymgbakar);

      int batas = 3;
      int total = int (subtotal);
      int ongkir = 15000;

      if(jrk > batas){
        ongkir = ongkir + 10000;
        total = subtotal + ongkir;
      }
      else{ 
        total = subtotal + ongkir;
      }
      
      tulis_data.open("api.data.txt");
      tulis_data << subtotal << endl;
      tulis_data << ongkir << endl;
      tulis_data << total << endl;
      tulis_data << bnyk_aymgeprek << endl;
      tulis_data << bnyk_aymgoreng << endl;
      tulis_data << bnyk_udanggrng << endl;
      tulis_data << bnyk_cumigrng << endl;
      tulis_data << bnyk_aymgbakar;
      tulis_data.close();
      
    }
  private :
    ifstream ambil_data;
    ofstream tulis_data;
    int hrg_aymgeprek = 21000;
    int hrg_aymgoreng = 17000;
    int hrg_udanggrg  = 19000;
    int hrg_cumigrg   = 20000;
    int hrg_aymbakar  = 25000;
    int bnyk_aymgeprek,bnyk_aymgoreng,bnyk_udanggrng,bnyk_cumigrng,bnyk_aymgbakar,jrk,total,ongkir;
};