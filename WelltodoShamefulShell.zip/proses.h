#include<iostream>
#include <fstream>w
using namespace std;

class Proses {
  public :
    void cetak(){
      cout << "Ini Proses \n";
    }

    void getData(){
      ambil_data.open("api.data.txt");
      bool ayam_geprek = true;
      bool ayam_goreng = true;
      bool udang_goreng = true;
      bool cumi_goreng = true;
      bool ayam_bakar = true;
      bool jarak = true;
      while(!ambil_data.eof()){
        if (ayam_geprek){
          ambil_data >> bnyk_geprek;
          ayam_geprek = false;
        }
        if (ayam_goreng){
          ambil_data >> bnyk_goreng;
          ayam_goreng = false;
        }
        if (udang_goreng){
          ambil_data >> bnyk_udang;
          udang_goreng = false;
        }
        if (cumi_goreng){
          ambil_data >> bnyk_cumi;
          cumi_goreng = false;
        }
        if (ayam_bakar){
          ambil_data >> bnyk_bakar;
          ayam_bakar = false;
        }
        if (jarak){
          ambil_data >> jrk;
          jarak = false;
        }
        
      }
      ambil_data.close();
    }

    void toFile(){
      int subtotal = (hrg_geprek * bnyk_geprek) + (hrg_goreng * bnyk_goreng) + (hrg_udang * bnyk_udang) + (hrg_cumi * bnyk_cumi) + (hrg_bakar * bnyk_bakar);

      int batas = 3;
      int total = int (subtotal);
      int ongkir = 15000;

      if(jrk > batas){
        ongkir = ongkir + 10000;
        total = subtotal + ongkir;
      }
      else{ 
        total = subtotal + ongkir;
      }
      
      tulis_data.open("api.data.txt");
      tulis_data << subtotal << endl;
      tulis_data << ongkir << endl;
      tulis_data << total << endl;
      tulis_data << bnyk_geprek << endl;
      tulis_data << bnyk_goreng << endl;
      tulis_data << bnyk_udang << endl;
      tulis_data << bnyk_cumi << endl;
      tulis_data << bnyk_bakar;
      tulis_data.close();
      
    }
  private :
    ifstream ambil_data;
    ofstream tulis_data;
    int hrg_geprek = 21000;
    int hrg_goreng = 17000;
    int hrg_udang  = 19000;
    int hrg_cumi   = 20000;
    int hrg_bakar  = 25000;
    int bnyk_geprek,bnyk_goreng,bnyk_udang,bnyk_cumi,bnyk_bakar,jrk,total,ongkir;
};