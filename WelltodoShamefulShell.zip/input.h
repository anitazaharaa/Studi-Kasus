#include<iostream>
#include <fstream>
using namespace std;

class Input{
  public:
    void cetak(){
      cout<<"Ini Proses \n";
      cout << "1. Ayam geprek : Rp. 21000" <<endl;
	    cout << "2. Ayam goreng : RP. 17000" <<endl;
	    cout <<	"3. Udang goreng : Rp. 19000" <<endl;
	    cout <<	"4. Cumi goreng : Rp. 20000" <<endl;
	    cout <<	"5. Ayam bakar : Rp. 25000" <<endl;
      cout << "Masukkan jumlah pesanan ayam geprek : "; cin >> bnyk_geprek;
	cout << "Masukkan jumlah pesanan ayam goreng : "; cin >> bnyk_goreng;
	cout << "Masukkan jumlah pesanan udang goreng : "; cin >> bnyk_udang;
	cout << "Masukkan jumlah pesanan cumi goreng : "; cin >> bnyk_cumi;
	cout << "Masukkan jumlah pesanan ayam bakar : "; cin >> bnyk_bakar;
	cout << "Masukkan jarak rumah anda dalam km : "; cin >> jarak;
    }
    void toFile(){
      tulis_data.open("api.data.txt");
      tulis_data << bnyk_geprek << endl;
      tulis_data << bnyk_goreng << endl;
      tulis_data << bnyk_udang << endl;
      tulis_data << bnyk_cumi << endl;
      tulis_data << bnyk_bakar << endl;
}

  private:
  ofstream tulis_data;
int bnyk_geprek,bnyk_goreng,bnyk_cumi,bnyk_udang,bnyk_bakar,total1,total2,total3,total4,total5,total,jarak,ongkir1,ongkir2,diskon,totals,bayar,kembali;
};